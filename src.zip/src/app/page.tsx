import AnimatedCard from "@/component/hero/AnimatedCard";

export default function Home() {
  return (
    <>
      <section className="w-full h-[300vh]">
        <AnimatedCard direction="1" />
      </section>
      <section className="w-full h-[300vh]">
        <AnimatedCard direction="-1" />
      </section>
      <section className="w-full h-[300vh]">
        <AnimatedCard direction="1" />
      </section>
    </>
  );
}
