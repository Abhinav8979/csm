"use client";
import Image from "next/image";
import Plane from "../../../public/assets/videos/plane.jpg";
import { motion, useScroll, useTransform } from "framer-motion";
import { useEffect, useRef, useState } from "react";
import Aviation from "../../../public/assets/videos/Aviation.jpeg";

export default function AnimatedCard({ direction }: { direction: "1" | "-1" }) {
  const [windowWidth, setWindowWidth] = useState(1200);
  const containerRef = useRef<HTMLDivElement>(null);
  const { scrollYProgress } = useScroll({
    target: containerRef,
  });

  const cloudWidth = windowWidth < 768 ? 210 : windowWidth < 1024 ? 300 : 480;

  const planeX = useTransform(
    scrollYProgress,
    [0, 1],
    [
      direction === "1" ? "-100vw" : "100vw",
      direction === "1" ? "100vw" : "-100vw",
    ]
  );

  const cloudX = useTransform(
    scrollYProgress,
    [0, 0.9],
    [direction === "1" ? "-100%" : "100vw", windowWidth < 768 ? "20vw" : "35vw"]
  );

  useEffect(() => {
    const handleResize = () => setWindowWidth(window.innerWidth);
    handleResize();
    window.addEventListener("resize", handleResize);
    return () => window.removeEventListener("resize", handleResize);
  }, []);

  return (
    <div ref={containerRef} className="w-full h-full">
      <div className="sticky top-0 w-full h-screen overflow-hidden flex items-center">
        <div className="relative w-full h-full">
          {/* Cloud */}
          <motion.div
            id="cloud-clip-path"
            style={{
              x: cloudX,
              position: "absolute",
              top: "50%",
              translateY: "-50%",
              zIndex: 10,
              width: `${cloudWidth}px`,
              height: `${cloudWidth}px`,
            }}
          >
            <Image
              src={Aviation}
              alt="Aviation background"
              className="w-full h-full opacity-40"
              priority
            />
            <div className="absolute w-full p-5 left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2 flex flex-col gap-4">
              <h1 className="text-center text-sm md:text-3xl lg:text-4xl font-bold">
                Direct Charter to Public
              </h1>
              <p className="text-black md:text-balance text-xs text-center">
                Located in Central California, we are positioned well to depart
                from all Northern and Southern California airport locations.
              </p>
            </div>
          </motion.div>

          {/* Plane */}
          <motion.div
            initial={{ rotate: direction === "1" ? 0 : 180 }}
            style={{ x: planeX }}
            className="absolute top-1/2 -translate-y-1/2 w-auto flex gap-10"
          >
            <Image
              src={Plane}
              alt="Plane"
              className={`${
                windowWidth < 768
                  ? "w-[180px]"
                  : windowWidth < 1024
                  ? "w-[300px]"
                  : "w-[400px]"
              } h-auto`}
            />
          </motion.div>
        </div>
      </div>
    </div>
  );
}
